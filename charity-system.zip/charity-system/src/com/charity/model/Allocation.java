package com.charity.model;

import java.time.LocalDate;

/** One row of the allocations table (money spent by an organization). */
public class Allocation {

    private int       allocationId;
    private String    purpose;
    private double    amount;
    private LocalDate allocatedOn;
    private int       orgId;
    private String    orgName;

    public Allocation(String purpose, double amount, LocalDate allocatedOn, int orgId) {
        this.purpose     = purpose;
        this.amount      = amount;
        this.allocatedOn = allocatedOn;
        this.orgId       = orgId;
    }

    public Allocation(int allocationId, String purpose, double amount,
                      LocalDate allocatedOn, int orgId, String orgName) {
        this(purpose, amount, allocatedOn, orgId);
        this.allocationId = allocationId;
        this.orgName      = orgName;
    }

    public int       getAllocationId() { return allocationId; }
    public String    getPurpose()      { return purpose; }
    public double    getAmount()       { return amount; }
    public LocalDate getAllocatedOn()  { return allocatedOn; }
    public int       getOrgId()        { return orgId; }
    public String    getOrgName()      { return orgName; }
}
