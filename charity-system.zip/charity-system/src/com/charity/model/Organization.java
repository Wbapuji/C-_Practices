package com.charity.model;

/** Plain data holder for one row of the organizations table. */
public class Organization {

    private int    orgId;
    private String name;
    private String city;
    private String contactEmail;

    // Used when INSERTing: no id yet, MySQL will generate it.
    public Organization(String name, String city, String contactEmail) {
        this.name = name;
        this.city = city;
        this.contactEmail = contactEmail;
    }

    // Used when READing a row back out of the database.
    public Organization(int orgId, String name, String city, String contactEmail) {
        this(name, city, contactEmail);
        this.orgId = orgId;
    }

    public int    getOrgId()        { return orgId; }
    public String getName()         { return name; }
    public String getCity()         { return city; }
    public String getContactEmail() { return contactEmail; }
}
