package com.charity.model;

import java.time.LocalDate;

/** One row of the donations table (money received by an organization). */
public class Donation {

    private int       donationId;
    private String    donorName;
    private double    amount;
    private LocalDate donationDate;
    private int       orgId;
    private String    orgName;

    public Donation(String donorName, double amount, LocalDate donationDate, int orgId) {
        this.donorName    = donorName;
        this.amount       = amount;
        this.donationDate = donationDate;
        this.orgId        = orgId;
    }

    public Donation(int donationId, String donorName, double amount,
                    LocalDate donationDate, int orgId, String orgName) {
        this(donorName, amount, donationDate, orgId);
        this.donationId = donationId;
        this.orgName    = orgName;
    }

    public int       getDonationId()   { return donationId; }
    public String    getDonorName()    { return donorName; }
    public double    getAmount()       { return amount; }
    public LocalDate getDonationDate() { return donationDate; }
    public int       getOrgId()        { return orgId; }
    public String    getOrgName()      { return orgName; }
}
