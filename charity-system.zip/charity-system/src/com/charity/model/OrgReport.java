package com.charity.model;

/**
 * NOT a database table. This holds one row of the dashboard report,
 * built by a query that JOINs and SUMs across three tables.
 */
public class OrgReport {

    private String orgName;
    private String city;
    private int    volunteerCount;
    private double totalDonated;
    private double totalAllocated;

    public OrgReport(String orgName, String city, int volunteerCount,
                     double totalDonated, double totalAllocated) {
        this.orgName        = orgName;
        this.city           = city;
        this.volunteerCount = volunteerCount;
        this.totalDonated   = totalDonated;
        this.totalAllocated = totalAllocated;
    }

    public String getOrgName()        { return orgName; }
    public String getCity()           { return city; }
    public int    getVolunteerCount() { return volunteerCount; }
    public double getTotalDonated()   { return totalDonated; }
    public double getTotalAllocated() { return totalAllocated; }

    /** Money still unspent. Calculated in Java, not stored in the database. */
    public double getBalance() { return totalDonated - totalAllocated; }
}
