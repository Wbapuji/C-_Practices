package com.charity.model;

/** One row of the volunteers table. orgName comes from a JOIN, for display only. */
public class Volunteer {

    private int    volunteerId;
    private String name;
    private String phone;
    private int    orgId;
    private String orgName;

    public Volunteer(String name, String phone, int orgId) {
        this.name  = name;
        this.phone = phone;
        this.orgId = orgId;
    }

    public Volunteer(int volunteerId, String name, String phone, int orgId, String orgName) {
        this(name, phone, orgId);
        this.volunteerId = volunteerId;
        this.orgName     = orgName;
    }

    public int    getVolunteerId() { return volunteerId; }
    public String getName()        { return name; }
    public String getPhone()       { return phone; }
    public int    getOrgId()       { return orgId; }
    public String getOrgName()     { return orgName; }
}
