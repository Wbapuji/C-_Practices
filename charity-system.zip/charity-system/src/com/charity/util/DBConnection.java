package com.charity.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * One job only: hand out a live connection to the MySQL database.
 *
 * Every DAO class calls DBConnection.getConnection(). That way the
 * database URL and password live in exactly ONE place in the project.
 */
public class DBConnection {

    // CHANGE THESE THREE LINES to match your own MySQL setup.
    private static final String URL      = "jdbc:mysql://localhost:3306/charity_db";
    private static final String USER     = "root";
    private static final String PASSWORD = "root";

    static {
        try {
            // Loads the MySQL driver class into memory.
            // Modern JDBC finds the driver automatically, but doing this
            // explicitly gives a clear error message if the .jar is missing.
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC driver not found on the classpath.", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
