package com.charity.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * Checks user input BEFORE it ever reaches the database.
 *
 * Each method either returns a clean value, or throws
 * IllegalArgumentException with a message the user can read.
 * The web layer catches that exception and shows the message.
 */
public class Validator {

    /** Field must not be null, empty, or only spaces. Returns the trimmed value. */
    public static String requireText(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }
        return value.trim();
    }

    /** Money field: must be a number and must be greater than zero. */
    public static double requireAmount(String value, String fieldName) {
        String text = requireText(value, fieldName);
        double amount;
        try {
            amount = Double.parseDouble(text);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(fieldName + " must be a number.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than zero.");
        }
        return amount;
    }

    /** Dropdown / foreign key field: must be a positive whole number. */
    public static int requireId(String value, String fieldName) {
        String text = requireText(value, fieldName);
        int id;
        try {
            id = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(fieldName + " is not valid.");
        }
        if (id <= 0) {
            throw new IllegalArgumentException(fieldName + " is not valid.");
        }
        return id;
    }

    /** Date field: must be YYYY-MM-DD and must not be in the future. */
    public static LocalDate requireDate(String value, String fieldName) {
        String text = requireText(value, fieldName);
        LocalDate date;
        try {
            date = LocalDate.parse(text);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException(fieldName + " must be in YYYY-MM-DD format.");
        }
        if (date.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException(fieldName + " cannot be in the future.");
        }
        return date;
    }

    /** Very simple email shape check: something@something.something */
    public static String requireEmail(String value, String fieldName) {
        String text = requireText(value, fieldName);
        if (!text.matches("^[^@\\s]+@[^@\\s]+\\.[a-zA-Z]{2,}$")) {
            throw new IllegalArgumentException(fieldName + " is not a valid email address.");
        }
        return text;
    }

    /** Mobile number: exactly 10 digits. */
    public static String requirePhone(String value, String fieldName) {
        String text = requireText(value, fieldName);
        if (!text.matches("^[0-9]{10}$")) {
            throw new IllegalArgumentException(fieldName + " must be exactly 10 digits.");
        }
        return text;
    }
}
