package com.charity.service;

import com.charity.dao.*;
import com.charity.model.*;
import com.charity.util.Validator;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * The middle layer. It sits between the web pages and the DAOs.
 *
 * Its two responsibilities:
 *   1. Validate raw form input and turn it into model objects.
 *   2. Enforce business RULES that SQL alone cannot express
 *      (for example: you cannot allocate more money than you received).
 *
 * There is no SQL in this file, and no HTML either.
 */
public class CharityService {

    private final OrganizationDAO organizationDAO = new OrganizationDAO();
    private final VolunteerDAO    volunteerDAO    = new VolunteerDAO();
    private final DonationDAO     donationDAO     = new DonationDAO();
    private final AllocationDAO   allocationDAO   = new AllocationDAO();
    private final ReportDAO       reportDAO       = new ReportDAO();

    // ---------------- reads ----------------

    public List<OrgReport>    dashboard()     throws SQLException { return reportDAO.organizationSummary(); }
    public List<Organization> organizations() throws SQLException { return organizationDAO.findAll(); }
    public List<Volunteer>    volunteers()    throws SQLException { return volunteerDAO.findAll(); }
    public List<Donation>     donations()     throws SQLException { return donationDAO.findAll(); }
    public List<Allocation>   allocations()   throws SQLException { return allocationDAO.findAll(); }
    public double             totalDonated()  throws SQLException { return donationDAO.totalDonated(); }

    // ---------------- writes ----------------

    public void addOrganization(Map<String, String> form) throws SQLException {
        String name  = Validator.requireText(form.get("name"), "Organization name");
        String city  = Validator.requireText(form.get("city"), "City");
        String email = Validator.requireEmail(form.get("contactEmail"), "Contact email");

        organizationDAO.insert(new Organization(name, city, email));
    }

    public void addVolunteer(Map<String, String> form) throws SQLException {
        String name  = Validator.requireText(form.get("name"), "Volunteer name");
        String phone = Validator.requirePhone(form.get("phone"), "Phone number");
        int    orgId = Validator.requireId(form.get("orgId"), "Organization");

        volunteerDAO.insert(new Volunteer(name, phone, orgId));
    }

    public void addDonation(Map<String, String> form) throws SQLException {
        String    donor  = Validator.requireText(form.get("donorName"), "Donor name");
        double    amount = Validator.requireAmount(form.get("amount"), "Amount");
        LocalDate date   = Validator.requireDate(form.get("donationDate"), "Donation date");
        int       orgId  = Validator.requireId(form.get("orgId"), "Organization");

        donationDAO.insert(new Donation(donor, amount, date, orgId));
    }

    public void addAllocation(Map<String, String> form) throws SQLException {
        String    purpose = Validator.requireText(form.get("purpose"), "Purpose");
        double    amount  = Validator.requireAmount(form.get("amount"), "Amount");
        LocalDate date    = Validator.requireDate(form.get("allocatedOn"), "Allocation date");
        int       orgId   = Validator.requireId(form.get("orgId"), "Organization");

        // ---- BUSINESS RULE ----
        // An organization can never allocate more than it has actually received.
        double received  = donationDAO.totalDonatedForOrg(orgId);
        double spent     = allocationDAO.totalAllocatedForOrg(orgId);
        double available = received - spent;

        if (amount > available) {
            throw new IllegalArgumentException(String.format(
                "Cannot allocate %.2f - this organization has only %.2f available "
                + "(received %.2f, already allocated %.2f).",
                amount, available, received, spent));
        }

        allocationDAO.insert(new Allocation(purpose, amount, date, orgId));
    }

    public void deleteOrganization(Map<String, String> form) throws SQLException {
        int orgId = Validator.requireId(form.get("orgId"), "Organization");
        organizationDAO.deleteById(orgId);
    }
}
