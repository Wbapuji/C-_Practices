package com.charity.web;

/** Small helpers for building HTML safely, plus the shared page layout. */
public class Html {

    /**
     * Escapes text before it goes into a page.
     * Without this, a donor name like <b>Ravi</b> would be treated as HTML tags
     * instead of being shown as plain text.
     */
    public static String escape(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                   .replace("<", "&lt;")
                   .replace(">", "&gt;")
                   .replace("\"", "&quot;");
    }

    /** 25000.0 -> "25,000.00" */
    public static String money(double value) {
        return String.format("%,.2f", value);
    }

    /** Wraps page content in the common header, nav bar and footer. */
    public static String page(String title, String activePath, String banner, String content) {
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <title>%s | Charity Operations</title>
              <link rel="stylesheet" href="/style.css">
            </head>
            <body>
              <header>
                <h1>Charity Operations Management System</h1>
                <nav>
                  %s
                </nav>
              </header>
              <main>
                <h2>%s</h2>
                %s
                %s
              </main>
              <footer>Java &middot; JDBC &middot; MySQL &middot; HTML &middot; CSS</footer>
            </body>
            </html>
            """.formatted(escape(title), navBar(activePath), escape(title),
                          banner == null ? "" : banner, content);
    }

    private static String navBar(String activePath) {
        String[][] links = {
            {"/",              "Dashboard"},
            {"/organizations", "Organizations"},
            {"/volunteers",    "Volunteers"},
            {"/donations",     "Donations"},
            {"/allocations",   "Fund Allocation"}
        };
        StringBuilder sb = new StringBuilder();
        for (String[] link : links) {
            String cls = link[0].equals(activePath) ? " class=\"active\"" : "";
            sb.append("<a href=\"").append(link[0]).append("\"").append(cls).append(">")
              .append(link[1]).append("</a>");
        }
        return sb.toString();
    }

    public static String successBanner(String message) {
        return "<p class=\"banner success\">" + escape(message) + "</p>";
    }

    public static String errorBanner(String message) {
        return "<p class=\"banner error\">" + escape(message) + "</p>";
    }
}
