package com.charity.web;

import com.charity.model.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Builds the HTML body of each page. No SQL here, no routing here -
 * this file only turns lists of objects into tables and forms.
 */
public class Pages {

    // ---------------------------------------------------------------- dashboard

    public static String dashboard(List<OrgReport> report, double grandTotal) {
        StringBuilder rows = new StringBuilder();
        for (OrgReport r : report) {
            rows.append("<tr>")
                .append(cell(r.getOrgName()))
                .append(cell(r.getCity()))
                .append(num(String.valueOf(r.getVolunteerCount())))
                .append(num(Html.money(r.getTotalDonated())))
                .append(num(Html.money(r.getTotalAllocated())))
                .append(num(Html.money(r.getBalance())))
                .append("</tr>");
        }
        if (report.isEmpty()) {
            rows.append("<tr><td colspan=\"6\" class=\"empty\">No organizations yet. "
                      + "Add one to get started.</td></tr>");
        }

        return """
            <div class="cards">
              <div class="card"><span class="card-label">Organizations</span>
                                <span class="card-value">%d</span></div>
              <div class="card"><span class="card-label">Total donations received</span>
                                <span class="card-value">%s</span></div>
            </div>

            <table>
              <thead>
                <tr>
                  <th>Organization</th><th>City</th><th class="r">Volunteers</th>
                  <th class="r">Received</th><th class="r">Allocated</th><th class="r">Balance</th>
                </tr>
              </thead>
              <tbody>%s</tbody>
            </table>
            """.formatted(report.size(), Html.money(grandTotal), rows.toString());
    }

    // ------------------------------------------------------------ organizations

    public static String organizations(List<Organization> orgs) {
        StringBuilder rows = new StringBuilder();
        for (Organization o : orgs) {
            rows.append("<tr>")
                .append(cell(o.getName()))
                .append(cell(o.getCity()))
                .append(cell(o.getContactEmail()))
                .append("</tr>");
        }
        if (orgs.isEmpty()) rows.append(emptyRow(3));

        return """
            <form method="post" action="/organizations/add" class="entry-form">
              <label>Organization name <input type="text" name="name" maxlength="100"></label>
              <label>City <input type="text" name="city" maxlength="50"></label>
              <label>Contact email <input type="text" name="contactEmail" maxlength="100"></label>
              <button type="submit">Save organization</button>
            </form>

            <table>
              <thead><tr><th>Name</th><th>City</th><th>Contact email</th></tr></thead>
              <tbody>%s</tbody>
            </table>
            """.formatted(rows.toString());
    }

    // --------------------------------------------------------------- volunteers

    public static String volunteers(List<Volunteer> volunteers, List<Organization> orgs) {
        StringBuilder rows = new StringBuilder();
        for (Volunteer v : volunteers) {
            rows.append("<tr>")
                .append(cell(v.getName()))
                .append(cell(v.getPhone()))
                .append(cell(v.getOrgName()))
                .append("</tr>");
        }
        if (volunteers.isEmpty()) rows.append(emptyRow(3));

        return """
            <form method="post" action="/volunteers/add" class="entry-form">
              <label>Volunteer name <input type="text" name="name" maxlength="100"></label>
              <label>Phone (10 digits) <input type="text" name="phone" maxlength="10"></label>
              <label>Organization %s</label>
              <button type="submit">Save volunteer</button>
            </form>

            <table>
              <thead><tr><th>Name</th><th>Phone</th><th>Organization</th></tr></thead>
              <tbody>%s</tbody>
            </table>
            """.formatted(orgDropdown(orgs), rows.toString());
    }

    // ---------------------------------------------------------------- donations

    public static String donations(List<Donation> donations, List<Organization> orgs) {
        StringBuilder rows = new StringBuilder();
        for (Donation d : donations) {
            rows.append("<tr>")
                .append(cell(d.getDonationDate().toString()))
                .append(cell(d.getDonorName()))
                .append(cell(d.getOrgName()))
                .append(num(Html.money(d.getAmount())))
                .append("</tr>");
        }
        if (donations.isEmpty()) rows.append(emptyRow(4));

        return """
            <form method="post" action="/donations/add" class="entry-form">
              <label>Donor name <input type="text" name="donorName" maxlength="100"></label>
              <label>Amount <input type="text" name="amount"></label>
              <label>Date <input type="date" name="donationDate" value="%s"></label>
              <label>Organization %s</label>
              <button type="submit">Record donation</button>
            </form>

            <table>
              <thead><tr><th>Date</th><th>Donor</th><th>Organization</th>
                         <th class="r">Amount</th></tr></thead>
              <tbody>%s</tbody>
            </table>
            """.formatted(LocalDate.now(), orgDropdown(orgs), rows.toString());
    }

    // -------------------------------------------------------------- allocations

    public static String allocations(List<Allocation> allocations, List<Organization> orgs) {
        StringBuilder rows = new StringBuilder();
        for (Allocation a : allocations) {
            rows.append("<tr>")
                .append(cell(a.getAllocatedOn().toString()))
                .append(cell(a.getPurpose()))
                .append(cell(a.getOrgName()))
                .append(num(Html.money(a.getAmount())))
                .append("</tr>");
        }
        if (allocations.isEmpty()) rows.append(emptyRow(4));

        return """
            <p class="note">An allocation is rejected if it exceeds the money that
            organization has actually received.</p>

            <form method="post" action="/allocations/add" class="entry-form">
              <label>Purpose <input type="text" name="purpose" maxlength="100"></label>
              <label>Amount <input type="text" name="amount"></label>
              <label>Date <input type="date" name="allocatedOn" value="%s"></label>
              <label>Organization %s</label>
              <button type="submit">Allocate funds</button>
            </form>

            <table>
              <thead><tr><th>Date</th><th>Purpose</th><th>Organization</th>
                         <th class="r">Amount</th></tr></thead>
              <tbody>%s</tbody>
            </table>
            """.formatted(LocalDate.now(), orgDropdown(orgs), rows.toString());
    }

    // ------------------------------------------------------------------ helpers

    private static String orgDropdown(List<Organization> orgs) {
        StringBuilder sb = new StringBuilder("<select name=\"orgId\">");
        sb.append("<option value=\"\">-- select --</option>");
        for (Organization o : orgs) {
            sb.append("<option value=\"").append(o.getOrgId()).append("\">")
              .append(Html.escape(o.getName())).append("</option>");
        }
        return sb.append("</select>").toString();
    }

    private static String cell(String text) {
        return "<td>" + Html.escape(text) + "</td>";
    }

    private static String num(String text) {
        return "<td class=\"r\">" + Html.escape(text) + "</td>";
    }

    private static String emptyRow(int columns) {
        return "<tr><td colspan=\"" + columns + "\" class=\"empty\">No records yet.</td></tr>";
    }
}
