package com.charity.web;

import com.charity.service.CharityService;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * The entry point. Starts a web server on port 8080 and maps each URL
 * to a service call plus a page.
 *
 * This uses the HTTP server that ships inside the JDK, so the project runs
 * with plain "java" - no Tomcat, no Maven, no external framework.
 * The structure is the same as a servlet app: a request comes in, the
 * service layer does the work, a page is rendered back.
 */
public class WebServer {

    private static final int PORT = 8080;
    private static final CharityService service = new CharityService();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/", WebServer::route);
        server.start();
        System.out.println("Charity Operations Management System");
        System.out.println("Open http://localhost:" + PORT + " in your browser.");
        System.out.println("Press Ctrl+C to stop.");
    }

    // ------------------------------------------------------------------ routing

    private static void route(HttpExchange exchange) throws IOException {
        String path   = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod();

        try {
            if (path.equals("/style.css")) {
                serveCss(exchange);
            } else if (method.equals("GET")) {
                handleGet(exchange, path);
            } else if (method.equals("POST")) {
                handlePost(exchange, path);
            } else {
                sendHtml(exchange, 405, Html.page("Not allowed", path, null,
                        "<p>That request method is not supported.</p>"));
            }
        } catch (SQLException e) {
            // Database is down, or the query failed. Show it instead of crashing.
            e.printStackTrace();
            sendHtml(exchange, 500, Html.page("Database error", path,
                    Html.errorBanner("Could not reach the database: " + e.getMessage()),
                    "<p>Check that MySQL is running and that the login details in "
                    + "DBConnection.java are correct.</p>"));
        } catch (Exception e) {
            e.printStackTrace();
            sendHtml(exchange, 500, Html.page("Unexpected error", path,
                    Html.errorBanner("Something went wrong: " + e.getMessage()), ""));
        }
    }

    private static void handleGet(HttpExchange exchange, String path)
            throws IOException, SQLException {

        Map<String, String> query = parseParams(exchange.getRequestURI().getRawQuery());
        String banner = null;
        if (query.containsKey("msg")) banner = Html.successBanner(query.get("msg"));
        if (query.containsKey("err")) banner = Html.errorBanner(query.get("err"));

        switch (path) {
            case "/" -> sendHtml(exchange, 200, Html.page("Dashboard", path, banner,
                    Pages.dashboard(service.dashboard(), service.totalDonated())));

            case "/organizations" -> sendHtml(exchange, 200, Html.page("Organizations", path, banner,
                    Pages.organizations(service.organizations())));

            case "/volunteers" -> sendHtml(exchange, 200, Html.page("Volunteers", path, banner,
                    Pages.volunteers(service.volunteers(), service.organizations())));

            case "/donations" -> sendHtml(exchange, 200, Html.page("Donations", path, banner,
                    Pages.donations(service.donations(), service.organizations())));

            case "/allocations" -> sendHtml(exchange, 200, Html.page("Fund Allocation", path, banner,
                    Pages.allocations(service.allocations(), service.organizations())));

            default -> sendHtml(exchange, 404, Html.page("Page not found", path, null,
                    "<p>No page at " + Html.escape(path) + ".</p>"));
        }
    }

    private static void handlePost(HttpExchange exchange, String path) throws IOException {
        Map<String, String> form = parseParams(readBody(exchange));
        String listPage = path.replace("/add", "");   // "/donations/add" -> "/donations"

        try {
            switch (path) {
                case "/organizations/add" -> {
                    service.addOrganization(form);
                    redirect(exchange, listPage, "Organization saved.", null);
                }
                case "/volunteers/add" -> {
                    service.addVolunteer(form);
                    redirect(exchange, listPage, "Volunteer saved.", null);
                }
                case "/donations/add" -> {
                    service.addDonation(form);
                    redirect(exchange, listPage, "Donation recorded.", null);
                }
                case "/allocations/add" -> {
                    service.addAllocation(form);
                    redirect(exchange, listPage, "Funds allocated.", null);
                }
                default -> sendHtml(exchange, 404, Html.page("Page not found", path, null,
                        "<p>No such action.</p>"));
            }
        } catch (IllegalArgumentException e) {
            // Thrown by Validator or by a business rule in CharityService.
            // The user sees the exact reason and can correct the form.
            redirect(exchange, listPage, null, e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            redirect(exchange, listPage, null, "Could not save: " + e.getMessage());
        }
    }

    // ------------------------------------------------- request / response plumbing

    /** Turns "name=Arun&orgId=1" into a Map. Used for both query strings and form bodies. */
    private static Map<String, String> parseParams(String raw) {
        Map<String, String> params = new HashMap<>();
        if (raw == null || raw.isEmpty()) return params;

        for (String pair : raw.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String key   = eq < 0 ? pair : pair.substring(0, eq);
            String value = eq < 0 ? ""   : pair.substring(eq + 1);
            params.put(URLDecoder.decode(key,   StandardCharsets.UTF_8),
                       URLDecoder.decode(value, StandardCharsets.UTF_8));
        }
        return params;
    }

    private static String readBody(HttpExchange exchange) throws IOException {
        return new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    private static void sendHtml(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }

    /**
     * Sends the browser back to the list page after a form submit, carrying a
     * message in the URL. This is the "redirect after POST" pattern - it stops
     * a browser refresh from submitting the same donation twice.
     */
    private static void redirect(HttpExchange exchange, String path, String message, String error)
            throws IOException {
        StringBuilder location = new StringBuilder(path);
        if (message != null) {
            location.append("?msg=").append(URLEncoder.encode(message, StandardCharsets.UTF_8));
        } else if (error != null) {
            location.append("?err=").append(URLEncoder.encode(error, StandardCharsets.UTF_8));
        }
        exchange.getResponseHeaders().set("Location", location.toString());
        exchange.sendResponseHeaders(302, -1);
        exchange.close();
    }

    private static void serveCss(HttpExchange exchange) throws IOException {
        Path cssFile = Path.of("web", "style.css");
        if (!Files.exists(cssFile)) {
            sendHtml(exchange, 404, "/* style.css not found - run java from the project root */");
            return;
        }
        byte[] bytes = Files.readAllBytes(cssFile);
        exchange.getResponseHeaders().set("Content-Type", "text/css; charset=utf-8");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }
}
