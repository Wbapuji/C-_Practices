@echo off
REM Compiles and runs the project. Run from the project root folder.

if not exist lib\mysql-connector-j-*.jar (
  echo ERROR: MySQL connector jar not found in lib\
  echo Download mysql-connector-j-^<version^>.jar into the lib folder.
  exit /b 1
)

echo Compiling...
if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt
del sources.txt

echo Starting server...
for %%f in (lib\mysql-connector-j-*.jar) do set JAR=%%f
java -cp "out;%JAR%" com.charity.web.WebServer
