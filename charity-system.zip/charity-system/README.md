# Charity Operations Management System

A small full-stack web application: **Java + JDBC + MySQL + HTML + CSS**.
No frameworks, no Maven, no Tomcat — it runs with two commands.

Four things it manages: **organizations**, **volunteers**, **donations received**, and **funds allocated**, plus a dashboard that reports totals per organization.

---

## 1. Setup (about 10 minutes)

**You need:** JDK 17 or newer (`java -version`), and MySQL installed and running.

**Step 1 — create the database**

```bash
mysql -u root -p < schema.sql
```

This creates `charity_db`, four tables, and some sample rows.

**Step 2 — add the MySQL driver**

Download `mysql-connector-j-<version>.jar` from
https://dev.mysql.com/downloads/connector/j/ (pick "Platform Independent")
and drop the `.jar` into the `lib/` folder.

**Step 3 — set your MySQL password**

Open `src/com/charity/util/DBConnection.java` and change `USER` / `PASSWORD`
to your own MySQL login.

**Step 4 — run**

```bash
./run.sh          # Linux / macOS
run.bat           # Windows
```

Then open **http://localhost:8080**

If you'd rather run it manually:

```bash
javac -d out $(find src -name "*.java")
java -cp "out:lib/mysql-connector-j-9.1.0.jar" com.charity.web.WebServer
```

Run it from the project root — the server reads `web/style.css` from a relative path.

---

## 2. How a request travels through the code

This is the single most useful thing to be able to explain. Follow one donation:

```
Browser form submit  POST /donations/add
        |
        v
WebServer.java      reads the form fields into a Map
        |            "which URL is this? which method should handle it?"
        v
CharityService.java  validates each field, applies business rules,
        |            builds a Donation object
        v
DonationDAO.java     writes the SQL, fills the ? placeholders, runs it
        |
        v
MySQL                row inserted into donations table
        |
        v
Browser redirected back to /donations, which reads the list back out
```

**The rule this structure follows:** each layer only knows about the layer directly below it.

- `WebServer` / `Pages` — HTML only. **No SQL anywhere in these files.**
- `CharityService` — rules and validation only. No SQL, no HTML.
- `*DAO` — SQL only. No HTML, no validation.
- `model/*` — plain data holders. No logic at all.

That's what "layered architecture" means in practice. If someone asks why you did it that way: *to move from MySQL to another database, only the DAO files change; everything above them is untouched.*

---

## 3. The files

```
schema.sql                          4 tables + sample data

src/com/charity/
  util/DBConnection.java            the ONLY place the DB URL and password live
  util/Validator.java               reusable input checks, throws readable errors

  model/Organization.java           one class per table row
  model/Volunteer.java
  model/Donation.java
  model/Allocation.java
  model/OrgReport.java              NOT a table — one row of the dashboard report

  dao/OrganizationDAO.java          insert / findAll / deleteById
  dao/VolunteerDAO.java             insert / findAll (with a JOIN)
  dao/DonationDAO.java              insert / findAll / SUM queries
  dao/AllocationDAO.java            insert / findAll / SUM per organization
  dao/ReportDAO.java                the dashboard aggregate query

  service/CharityService.java       validation + business rules
  web/WebServer.java                starts the server, maps URLs to actions
  web/Pages.java                    builds the HTML tables and forms
  web/Html.java                     shared layout, HTML escaping

web/style.css                       plain CSS
```

**Read them in this order:** `schema.sql` → one model → one DAO → `CharityService` → `WebServer`. Bottom-up is much easier than top-down here.

---

## 4. The database

```
organizations                  volunteers
  org_id (PK)  <---------------  org_id (FK)
  name                          volunteer_id (PK)
  city                          name
  contact_email                 phone

     ^                    ^
     |                    |
donations              allocations
  org_id (FK)            org_id (FK)
  donation_id (PK)       allocation_id (PK)
  donor_name             purpose
  amount                 amount
  donation_date          allocated_on
```

One organization has many volunteers, many donations, and many allocations — three one-to-many relationships. The organization's name is stored **once**, in `organizations`; everywhere else only `org_id` is stored, and the name is fetched with a JOIN when it needs to be displayed.

**Why that matters:** if you stored the organization name in every donation row, renaming an organization would mean updating hundreds of rows, and a typo in one row would silently create a second "organization". Storing it once removes that whole class of bug. That is the practical point of normalization.

---

## 5. The two pieces of real logic

Everything else is CRUD. These two are worth understanding properly, because they're the interesting parts.

### The over-allocation rule (`CharityService.addAllocation`)

An organization cannot allocate more money than it actually received. Before inserting, the service asks two SUM queries — total received, total already allocated — subtracts, and rejects the allocation if the new amount exceeds what's left.

**Try it:** Helping Hands Trust has 30,000 in donations and 18,000 already allocated. Try to allocate 20,000 — it's rejected with a message showing the actual available balance.

Why this lives in the service layer and not in SQL: it's a rule about *your* organization's policy, it needs two queries plus arithmetic to evaluate, and it must produce a message a user can read. A database constraint can't do any of that.

### The report query (`ReportDAO`)

The obvious way to build the dashboard is one big JOIN across all four tables, then SUM. **That gives wrong numbers.** If an organization has 3 volunteers and 4 donations, the join produces 3 × 4 = 12 rows, and every donation amount gets counted three times.

The fix used here is a separate sub-query per total, so each SUM counts its own rows exactly once:

```sql
SELECT o.name, o.city,
  (SELECT COUNT(*)                    FROM volunteers  v WHERE v.org_id = o.org_id) AS volunteer_count,
  (SELECT COALESCE(SUM(d.amount), 0)  FROM donations   d WHERE d.org_id = o.org_id) AS total_donated,
  (SELECT COALESCE(SUM(a.amount), 0)  FROM allocations a WHERE a.org_id = o.org_id) AS total_allocated
FROM organizations o
ORDER BY total_donated DESC;
```

`COALESCE` is there because `SUM()` over zero rows returns `NULL`, not `0` — a new organization would show a blank instead of 0.00.

If you can explain this one query and *why* the naive JOIN is wrong, you'll be ahead of most candidates talking about a college project.

---

## 6. Interview questions this project invites

Work through these out loud. Short answers are fine — you just need to not freeze.

**"Walk me through your project."**
Four tables, layered Java backend, browser front end. A form submit hits the server, the service layer validates it and applies business rules, a DAO turns it into a parameterized SQL statement, the dashboard reads it back with an aggregate query. Then mention the over-allocation rule — that's the part that sounds like a real requirement rather than a tutorial.

**"What is a DAO? Why not just put SQL in the page?"**
A class whose only job is database access for one entity — `DonationDAO` has `insert()` and `findAll()`, and nothing above it contains SQL. Mixing SQL into pages means the same query gets copy-pasted in five places and every one has to be found when the schema changes.

**"Explain your JDBC flow."**
Get a `Connection` from `DriverManager` → `prepareStatement(sql)` → fill placeholders with `setString` / `setInt` / `setDouble` / `setDate` → `executeQuery()` for SELECT or `executeUpdate()` for INSERT/UPDATE/DELETE → loop the `ResultSet` with `rs.next()` → close everything.

**"How do you close connections?"**
`try-with-resources`. `Connection`, `PreparedStatement` and `ResultSet` all implement `AutoCloseable`, so declaring them in the `try (...)` header closes them automatically in reverse order — even if an exception is thrown. A `finally` block does the same thing but takes about eight lines and is easy to get wrong.

**"`PreparedStatement` or `Statement`?"**
`PreparedStatement` everywhere. It's precompiled, and the `?` placeholders are filled as *data*, so user input can never change the structure of the query. With string concatenation, a donor name of `' OR 1=1--` becomes part of the SQL.

**"Where does validation happen, and what did you validate?"**
In `Validator`, called from the service layer. Required fields non-empty; amount must parse as a number and be greater than zero; date must be `YYYY-MM-DD` and not in the future; phone exactly 10 digits; email must match a basic pattern. Each check throws `IllegalArgumentException` with a message, which the web layer catches and shows.

**"Checked vs unchecked exceptions — which did you use where?"**
`SQLException` is checked, so DAOs declare `throws SQLException` and the top-level handler turns it into an error page. Validation failures throw `IllegalArgumentException`, which is unchecked — a caller shouldn't be forced to wrap every field read in a try/catch, and it's a programming/input error rather than an environmental one.

**"What happens if MySQL is down?"**
`DBConnection.getConnection()` throws `SQLException`, it propagates up to the handler in `WebServer`, and the user gets an error page saying the database is unreachable instead of a stack trace or a hang.

**"Why redirect after a form submit instead of rendering the page directly?"**
Post/Redirect/Get. If the response to a POST is the page itself, pressing refresh re-submits the form and records the donation twice. Redirecting means refresh just re-runs a harmless GET.

**"Is this production-ready? What would you add?"**
No — and say so plainly. It has no login or user roles, connections are opened per query instead of pooled (HikariCP), amounts use `double` where `BigDecimal` would be correct for money, and multi-step operations aren't wrapped in transactions. Naming those weaknesses yourself lands much better than being caught by them.

**"Why not Spring Boot?"**
Doing it with raw JDBC first meant learning what a framework actually automates — connection handling, request routing, object mapping. That's a good, honest answer, and it's true of this code.

---

## 7. Things to try, so it's actually yours

Reading code isn't the same as knowing it. Each of these takes 15–30 minutes and forces you through a different layer:

1. **Add a `registered_on` DATE column to volunteers.** Touches schema, model, DAO, form, and table. Do this one first — it proves you understand the layering.
2. **Add a delete button for donations.** DAO method, route, form, and then discover the foreign key won't let you delete an organization that still has donations. That's a great thing to have run into.
3. **Add a search box** that filters donations by donor name (`WHERE donor_name LIKE ?`).
4. **Break something on purpose.** Change a `?` to string concatenation and try entering `' OR '1'='1` — then you've *seen* SQL injection, not just read about it.
5. **Stop MySQL and reload the page.** See where the error surfaces and how it's handled.

---

## 8. Resume bullets that match this code

These are defensible because every claim points at something in the repo:

- Built a full-stack Charity Operations Management System (Java, JDBC, MySQL, HTML, CSS) to manage organizations, volunteers, donations, and fund allocation.
- Designed a relational MySQL schema with four tables and foreign-key relationships, and implemented data access through DAO classes using parameterized JDBC statements.
- Separated the application into web, service, DAO, and model layers so that database access, business rules, and presentation stayed independent of each other.
- Implemented a validation layer and business rules — including a check that prevents allocating more funds than an organization has received — with exception handling that reports errors to the user instead of failing silently.

If the interviewer asks whether it's complete: it does what's described, and the honest gaps are authentication, connection pooling, and transactions. That answer is fine. Nobody expects a college project to be a bank.
