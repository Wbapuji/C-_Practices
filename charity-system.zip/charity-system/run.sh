#!/bin/bash
# Compiles and runs the project.  Run this from the project root folder.
# Linux / macOS.  For Windows use run.bat

set -e

JAR=$(ls lib/mysql-connector-j-*.jar 2>/dev/null | head -1)
if [ -z "$JAR" ]; then
  echo "ERROR: MySQL connector jar not found in lib/"
  echo "Download mysql-connector-j-<version>.jar and put it in the lib/ folder."
  exit 1
fi

echo "Compiling..."
mkdir -p out
javac -d out $(find src -name "*.java")

echo "Starting server..."
java -cp "out:$JAR" com.charity.web.WebServer
