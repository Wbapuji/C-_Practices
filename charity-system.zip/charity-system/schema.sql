-- ============================================================
-- Charity Operations Management System - Database Schema
-- Run this once in MySQL before starting the application.
-- ============================================================

DROP DATABASE IF EXISTS charity_db;
CREATE DATABASE charity_db;
USE charity_db;

-- ---------- Table 1: organizations (the "parent" table) ----------
CREATE TABLE organizations (
    org_id        INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    city          VARCHAR(50)  NOT NULL,
    contact_email VARCHAR(100) NOT NULL
);

-- ---------- Table 2: volunteers (each belongs to ONE organization) ----------
CREATE TABLE volunteers (
    volunteer_id INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    phone        VARCHAR(15)  NOT NULL,
    org_id       INT          NOT NULL,
    CONSTRAINT fk_volunteer_org FOREIGN KEY (org_id) REFERENCES organizations(org_id)
);

-- ---------- Table 3: donations (money coming IN to an organization) ----------
CREATE TABLE donations (
    donation_id   INT AUTO_INCREMENT PRIMARY KEY,
    donor_name    VARCHAR(100)   NOT NULL,
    amount        DECIMAL(10, 2) NOT NULL,
    donation_date DATE           NOT NULL,
    org_id        INT            NOT NULL,
    CONSTRAINT fk_donation_org FOREIGN KEY (org_id) REFERENCES organizations(org_id)
);

-- ---------- Table 4: allocations (money going OUT to a purpose) ----------
CREATE TABLE allocations (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    purpose       VARCHAR(100)   NOT NULL,
    amount        DECIMAL(10, 2) NOT NULL,
    allocated_on  DATE           NOT NULL,
    org_id        INT            NOT NULL,
    CONSTRAINT fk_allocation_org FOREIGN KEY (org_id) REFERENCES organizations(org_id)
);

-- ---------- Sample data so the dashboard is not empty ----------
INSERT INTO organizations (name, city, contact_email) VALUES
    ('Helping Hands Trust', 'Chennai', 'contact@helpinghands.org'),
    ('Green Earth Foundation', 'Coimbatore', 'info@greenearth.org'),
    ('Vidya Education Society', 'Madurai', 'admin@vidya.org');

INSERT INTO volunteers (name, phone, org_id) VALUES
    ('Arun Kumar', '9876543210', 1),
    ('Priya Ramesh', '9876501234', 1),
    ('Karthik S', '9812345678', 2);

INSERT INTO donations (donor_name, amount, donation_date, org_id) VALUES
    ('Ravi Shankar', 25000.00, '2026-01-15', 1),
    ('Meena Iyer',    5000.00, '2026-02-03', 1),
    ('Anonymous',    12000.00, '2026-02-20', 2),
    ('Suresh Babu',   8000.00, '2026-03-11', 3);

INSERT INTO allocations (purpose, amount, allocated_on, org_id) VALUES
    ('Food distribution drive', 18000.00, '2026-01-25', 1),
    ('Tree plantation supplies', 7000.00, '2026-02-28', 2);
