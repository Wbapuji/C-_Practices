#!/usr/bin/env python3
# ingest.py - PDF -> clean -> chunk -> embed -> ChromaDB

import os
import argparse
import logging

import fitz  # PyMuPDF
import chromadb
from sentence_transformers import SentenceTransformer

# Single source of truth for cleaning/chunking (no duplicated logic here)
from utils import clean_text, chunk_text

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

EMBED_MODEL = "sentence-transformers/all-mpnet-base-v2"
COLLECTION_NAME = "docs"


# ----------------------------
# Extract + chunk one PDF
# ----------------------------
def extract_pdf_chunks(pdf_path: str):
    """Return a list of {text, metadata} dicts for one PDF, page by page."""
    doc = fitz.open(pdf_path)
    all_chunks = []
    try:
        for page_num, page in enumerate(doc, start=1):
            text = clean_text(page.get_text("text"))
            if not text:
                continue
            for i, ch in enumerate(chunk_text(text)):
                all_chunks.append({
                    "text": ch,
                    "metadata": {
                        "source": os.path.basename(pdf_path),
                        "page": page_num,
                        "chunk": i,
                    },
                })
    finally:
        doc.close()
    logging.info(" -> extracted %d chunks from %s", len(all_chunks), os.path.basename(pdf_path))
    return all_chunks


# ----------------------------
# Ingest all PDFs in a directory
# ----------------------------
def ingest_all(docs_dir="docs", chroma_path="chroma_db", rebuild=False, batch_size=256):
    if not os.path.isdir(docs_dir):
        logging.error("Docs directory not found: %s", docs_dir)
        return

    logging.info("Loading embedding model (%s)...", EMBED_MODEL)
    embedder = SentenceTransformer(EMBED_MODEL)

    client = chromadb.PersistentClient(path=chroma_path)

    if rebuild:
        try:
            client.delete_collection(COLLECTION_NAME)
            logging.info("Existing collection dropped (rebuild mode).")
        except Exception:
            pass

    # NOTE: We compute embeddings ourselves and store them, so we do NOT attach
    # a SentenceTransformerEmbeddingFunction (that would load a second copy of
    # the model and never actually be used, since query.py queries by embedding).
    # We set the space to cosine so distances are comparable to the normalized
    # (unit-length) embeddings we insert.
    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )

    # Gather chunks from every PDF
    all_chunks = []
    for fname in sorted(os.listdir(docs_dir)):
        if not fname.lower().endswith(".pdf"):
            continue
        path = os.path.join(docs_dir, fname)
        logging.info("Processing PDF: %s", path)
        try:
            all_chunks.extend(extract_pdf_chunks(path))
        except Exception as e:
            logging.error("Failed to process %s: %s", fname, e)

    # Keep only non-empty texts and their aligned metadata/ids
    texts, metadatas, ids = [], [], []
    for c in all_chunks:
        t = str(c.get("text", "")).strip()
        if not t:
            continue
        m = c["metadata"]
        texts.append(t)
        metadatas.append(m)
        ids.append(f"{m['source']}_p{m['page']}_c{m['chunk']}")

    if not texts:
        logging.error("No valid text chunks found after cleaning. Aborting.")
        return

    logging.info("Computing embeddings for %d chunks...", len(texts))
    # normalize_embeddings=True -> unit vectors, so cosine space in Chroma and
    # dot-product similarity in query.py are consistent and meaningful.
    embeddings = embedder.encode(
        texts,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )

    # Insert in batches (avoids oversized single requests on large corpora)
    total = len(texts)
    for start in range(0, total, batch_size):
        end = min(start + batch_size, total)
        collection.add(
            documents=texts[start:end],
            embeddings=embeddings[start:end].tolist(),
            metadatas=metadatas[start:end],
            ids=ids[start:end],
        )
        logging.info("Stored %d/%d chunks...", end, total)

    logging.info("Ingestion complete: %d chunks in collection '%s'.", total, COLLECTION_NAME)


# ----------------------------
# CLI
# ----------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest PDFs into ChromaDB for RAG.")
    parser.add_argument("--dir", default="docs", help="Directory containing PDFs")
    parser.add_argument("--chroma", default="chroma_db", help="ChromaDB persistence path")
    parser.add_argument("--rebuild", action="store_true", help="Drop and rebuild the collection")
    args = parser.parse_args()

    ingest_all(docs_dir=args.dir, chroma_path=args.chroma, rebuild=args.rebuild)
