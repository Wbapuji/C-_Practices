#!/usr/bin/env python3
# query.py - modular RAG query: hybrid retrieval + MMR + cross-encoder rerank
#            + intent routing + adaptive confidence gating.

import os
import time
import logging
import json
import re
from typing import List, Dict, Any, Tuple, Optional

import numpy as np
import requests
from sentence_transformers import SentenceTransformer, util
from rank_bm25 import BM25Okapi
import chromadb
from chromadb.config import Settings
import joblib

from utils import tokenize_for_bm25

# Cross-encoder ships with sentence-transformers (the previous
# `from cross_encoder import CrossEncoder` referenced a package that does not
# exist, so reranking silently never ran). This is the correct import.
try:
    from sentence_transformers import CrossEncoder
    HAS_CE = True
except Exception:
    HAS_CE = False

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# ---------- Config ----------
CHROMA_PATH = "chroma_db"
COLLECTION_NAME = "docs"          # must match ingest.py
EMBED_MODEL = "sentence-transformers/all-mpnet-base-v2"
INTENT_CLASSIFIER_PATH = "intent_classifier.joblib"
LABEL_ENCODER_PATH = "intent_label_encoder.joblib"
RERANKER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"

# LLM endpoint (Ollama-compatible).
LLM_API_URL = "http://127.0.0.1:11434/api/chat"
LLM_MODEL_NAME = "my-mistral"

# Retrieval knobs
TOP_K_DENSE = 40
TOP_K_BM25 = 40
UNION_K = 60
MMR_K = 12
FINAL_K = 4

# Confidence knobs (operate on rerank scores normalized to [0, 1]).
# IMPORTANT: these are reasonable defaults, NOT tuned. Cross-encoder and
# cosine-fallback score distributions differ, so tune these against a small
# labelled eval set for your own corpus before trusting the gate.
MIN_TOP_SCORE = 0.50     # absolute floor for the best chunk
DELTA_TOP2 = 0.05        # top chunk should beat the 2nd by at least this
MEAN_GAP_FACTOR = 0.25   # top chunk should exceed the mean by this * std

# Post-filter alias map (keeps domain terms from being dropped by the gate)
AI_ALIAS_MAP = {
    "lora": {"lora", "low rank adaptation", "low-rank adaptation", "lowrank"},
    "qlora": {"qlora", "quantized lora", "quantized low rank"},
    "rag": {"rag", "retrieval augmented generation", "retrieval-augmented generation"},
}


# ---------- Helpers ----------
def now_s() -> float:
    return time.time()


def minmax(arr: np.ndarray) -> np.ndarray:
    """Min-max scale to [0, 1]; returns 0.5s if the range is degenerate."""
    arr = np.asarray(arr, dtype=float)
    if arr.size == 0:
        return arr
    lo, hi = float(arr.min()), float(arr.max())
    if hi - lo < 1e-9:
        return np.full_like(arr, 0.5)
    return (arr - lo) / (hi - lo)


def safe_json_from_response(text: str) -> Any:
    """Robustly parse JSON from possibly-noisy LLM output."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
        return {"message": {"content": text.strip()}}


def call_local_llm(prompt: str, max_tokens: int = 512) -> str:
    """Call an Ollama-compatible /api/chat endpoint; parse response shapes robustly."""
    payload = {
        "model": LLM_MODEL_NAME,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
        "options": {"num_predict": max_tokens},
    }
    try:
        r = requests.post(LLM_API_URL, json=payload, timeout=120)
        r.raise_for_status()
        data = safe_json_from_response(r.text)
        if isinstance(data, dict):
            msg = data.get("message")
            if isinstance(msg, dict) and "content" in msg:
                return msg["content"].strip()
            choices = data.get("choices")
            if choices:
                first = choices[0]
                if "message" in first and "content" in first["message"]:
                    return first["message"]["content"].strip()
                if "text" in first:
                    return first["text"].strip()
        return str(data)
    except Exception as e:
        logging.error("LLM call failed: %s", e)
        return "Error: could not generate response from local LLM."


# ---------- Intent classifier ----------
def load_intent_classifier(path: str, label_encoder_path: str):
    if os.path.exists(path) and os.path.exists(label_encoder_path):
        logging.info("Loading intent classifier from %s", path)
        return joblib.load(path), joblib.load(label_encoder_path)
    logging.warning("Intent classifier not found at %s - using prototype fallback.", path)
    return None, None


# Prototype fallback (only used if the trained classifier is absent).
PROTOTYPES = {
    "AI": [
        "What is retrieval augmented generation (RAG)?",
        "Explain transformer architecture",
        "What is LoRA fine tuning?",
    ],
    "CODING": [
        "Write a python function to reverse a linked list",
        "Show me Java code for BFS",
        "How to implement quicksort in Python?",
    ],
    "GENERAL": [
        "What is health?",
        "What is the capital of France?",
        "How do I boil an egg?",
    ],
    "CHITCHAT": [
        "You are doing great",
        "Thanks, you're awesome",
        "Good morning",
    ],
}


def build_prototype_embeddings(embedder) -> Dict[str, np.ndarray]:
    """Encode prototype examples ONCE at startup (previously recomputed per query)."""
    proto = {}
    for label, examples in PROTOTYPES.items():
        proto[label] = embedder.encode(examples, convert_to_numpy=True, normalize_embeddings=True)
    return proto


def prototype_intent(query_emb: np.ndarray, proto_embs: Dict[str, np.ndarray]) -> Tuple[str, float]:
    """Nearest-prototype intent classifier using precomputed prototype embeddings."""
    best_label, best_sim = None, -1.0
    for label, ex_embs in proto_embs.items():
        sim = float(np.max(util.cos_sim(query_emb, ex_embs).cpu().numpy()))
        if sim > best_sim:
            best_sim, best_label = sim, label
    return best_label, best_sim


# ---------- Keyword / alias post-filters ----------
def extract_keywords(q: str) -> List[str]:
    toks = re.findall(r"[A-Za-z0-9\-]+", q.lower())
    return list(dict.fromkeys(t for t in toks if len(t) >= 2))


def required_aliases_present(query: str, texts: List[str]) -> bool:
    q_low = query.lower()
    required = set()
    for aliases in AI_ALIAS_MAP.values():
        if any(a in q_low for a in aliases):
            required |= aliases
    if not required:
        return True
    alltxt = " ".join(texts).lower()
    return any(a in alltxt for a in required)


# ---------- Retrieval building blocks ----------
def build_bm25_index(docs: List[str]) -> Optional[BM25Okapi]:
    if not docs:
        return None
    # Tokenize the SAME way we tokenize queries (lowercased) so BM25 is
    # case-insensitive; the old .split() made 'RAG' and 'rag' mismatch.
    tokenized = [tokenize_for_bm25(d) for d in docs]
    return BM25Okapi(tokenized)


def mmr_select(query_emb: np.ndarray, candidate_embs: np.ndarray, k: int = 8,
               lambda_param: float = 0.7) -> List[int]:
    """
    Maximal Marginal Relevance: pick k candidates balancing relevance to the
    query against diversity from already-picked items. Embeddings are unit
    vectors, so dot product == cosine similarity.
    Returns positions into candidate_embs.
    """
    n = len(candidate_embs)
    if n <= k:
        return list(range(n))

    sims = candidate_embs @ query_emb.reshape(-1, 1)
    sims = sims.ravel()

    first = int(np.argmax(sims))
    selected = [first]
    pool = set(range(n)) - {first}

    while len(selected) < k and pool:
        best_pick, best_score = None, -np.inf
        for i in pool:
            rel = sims[i]
            div = max(float(np.dot(candidate_embs[i], candidate_embs[j])) for j in selected)
            score = lambda_param * rel - (1 - lambda_param) * div
            if score > best_score:
                best_score, best_pick = score, i
        selected.append(best_pick)
        pool.remove(best_pick)
    return selected


def normalize_rerank_scores(scores: List[float], used_cross_encoder: bool) -> List[float]:
    """
    Map rerank scores onto a common [0, 1] scale so the confidence thresholds
    mean the same thing regardless of which reranker ran.
      - cross-encoder logits -> sigmoid
      - cosine similarity     -> (cos + 1) / 2
    """
    arr = np.asarray(scores, dtype=float)
    if used_cross_encoder:
        return (1.0 / (1.0 + np.exp(-arr))).tolist()
    return ((arr + 1.0) / 2.0).tolist()


# ---------- Main pipeline ----------
def main():
    logging.info("Loading embedding model...")
    embedder = SentenceTransformer(EMBED_MODEL)
    proto_embs = build_prototype_embeddings(embedder)

    clf, label_enc = load_intent_classifier(INTENT_CLASSIFIER_PATH, LABEL_ENCODER_PATH)

    logging.info("Connecting to ChromaDB...")
    client = chromadb.PersistentClient(path=CHROMA_PATH, settings=Settings(anonymized_telemetry=False))
    try:
        collection = client.get_collection(COLLECTION_NAME)
    except Exception as e:
        logging.error("Chroma collection '%s' not found: %s", COLLECTION_NAME, e)
        logging.info("Run ingest.py first to populate the collection.")
        return

    # Hydrate the full corpus for BM25. collection.get() always returns ids,
    # so we capture them here and use THEM for BM25 hits (the original code
    # indexed into the dense-only id list, producing wrong ids for sparse hits).
    res = collection.get(include=["documents", "metadatas"])
    docs = res.get("documents", []) or []
    metas = res.get("metadatas", []) or []
    all_ids = res.get("ids", []) or []
    if not docs:
        logging.warning("No documents found in Chroma collection.")
    bm25 = build_bm25_index(docs)

    # Load the cross-encoder ONCE and reuse it (the original re-instantiated it
    # on every query inside the loop).
    reranker = None
    if HAS_CE:
        try:
            logging.info("Loading cross-encoder reranker (%s)...", RERANKER_MODEL)
            reranker = CrossEncoder(RERANKER_MODEL)
        except Exception as e:
            logging.warning("Could not load cross-encoder, will use cosine fallback: %s", e)
            reranker = None

    # ---------- REPL ----------
    while True:
        try:
            query = input("Enter query (or 'exit'): ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            break
        if not query:
            continue
        if query.lower() in ("exit", "quit"):
            break

        t0 = now_s()

        # Encode the query once (unit vector -> dot product == cosine).
        q_emb = embedder.encode(query, convert_to_numpy=True, normalize_embeddings=True)

        # --- Intent detection ---
        intent_conf = None
        if clf is not None and label_enc is not None:
            try:
                pred = clf.predict([q_emb])[0]
                intent = pred if isinstance(pred, str) else label_enc.inverse_transform([pred])[0]
            except Exception as e:
                logging.warning("Classifier error (%s) - using prototype fallback.", e)
                intent, intent_conf = prototype_intent(q_emb, proto_embs)
        else:
            intent, intent_conf = prototype_intent(q_emb, proto_embs)

        logging.info("Intent: %s%s", intent,
                     f" (sim={intent_conf:.3f})" if intent_conf is not None else "")

        # --- Chit-chat shortcut ---
        if intent == "CHITCHAT":
            lc = query.lower()
            if any(g in lc for g in ("hi", "hello", "hey")):
                resp = "Hi - how can I help with your research or questions today?"
            elif any(k in lc for k in ("thank", "thanks", "great", "nice", "good job", "well done")):
                resp = "Thanks - glad it's helping! What would you like next?"
            else:
                resp = "I'm here to help - ask me about your documents, AI topics, or coding."
            print("\nAnswer:\n", resp)
            print("\nSource: none (chit-chat)")
            print(f"\nTook {now_s() - t0:.2f}s\n")
            continue

        # --- Dense retrieval (Chroma, cosine space) ---
        dense_res = collection.query(
            query_embeddings=[q_emb.tolist()],
            n_results=TOP_K_DENSE,
            include=["documents", "metadatas", "distances"],
        )
        dense_docs = dense_res["documents"][0]
        dense_metas = dense_res["metadatas"][0]
        dense_ids = dense_res["ids"][0]
        dense_dists = dense_res["distances"][0]
        # cosine distance -> similarity in [-1, 1]
        dense_sims = [1.0 - float(d) for d in dense_dists]

        # --- Sparse retrieval (BM25 over the full corpus) ---
        sparse_docs, sparse_metas, sparse_ids, sparse_scores = [], [], [], []
        if bm25:
            b_scores = bm25.get_scores(tokenize_for_bm25(query))
            top_idx = np.argsort(b_scores)[::-1][:TOP_K_BM25]
            for idx in top_idx:
                if b_scores[idx] <= 0:
                    continue
                sparse_docs.append(docs[idx])
                sparse_metas.append(metas[idx] if idx < len(metas) else {})
                # Use the CORRECT id from the full corpus id list.
                sparse_ids.append(all_ids[idx] if idx < len(all_ids) else str(idx))
                sparse_scores.append(float(b_scores[idx]))

        # --- Merge into a pool. Normalize each source to [0, 1] first so the
        #     union selection isn't dominated by BM25's unbounded magnitudes. ---
        pool: Dict[str, Dict[str, Any]] = {}
        for doc, md, did, s in zip(dense_docs, dense_metas, dense_ids, minmax(dense_sims)):
            if did not in pool or s > pool[did]["score"]:
                pool[did] = {"text": doc or "", "meta": md or {}, "score": float(s)}
        for doc, md, did, s in zip(sparse_docs, sparse_metas, sparse_ids, minmax(sparse_scores)):
            if did not in pool or s > pool[did]["score"]:
                pool[did] = {"text": doc or "", "meta": md or {}, "score": float(s)}

        pool_items = sorted(pool.items(), key=lambda kv: kv[1]["score"], reverse=True)[:UNION_K]
        cand_texts = [v["text"] for _, v in pool_items]
        cand_metas = [v["meta"] for _, v in pool_items]

        # --- MMR for diversity ---
        if cand_texts:
            cand_embs = embedder.encode(cand_texts, convert_to_numpy=True, normalize_embeddings=True)
            sel_positions = mmr_select(q_emb, cand_embs, k=MMR_K, lambda_param=0.7)
            sel_texts = [cand_texts[i] for i in sel_positions]
            sel_metas = [cand_metas[i] for i in sel_positions]
            sel_embs = cand_embs[sel_positions]
        else:
            sel_texts, sel_metas, sel_embs = [], [], np.empty((0,))

        # --- Rerank: cross-encoder if available, else cosine fallback ---
        used_cross_encoder = False
        reranked: List[Tuple[str, dict, float]] = []
        if reranker is not None and sel_texts:
            try:
                pairs = [[query, t] for t in sel_texts]
                scores = reranker.predict(pairs).tolist()
                reranked = sorted(zip(sel_texts, sel_metas, scores), key=lambda x: x[2], reverse=True)
                used_cross_encoder = True
            except Exception as e:
                logging.warning("Cross-encoder failed, falling back to cosine: %s", e)
        if not reranked and sel_texts:
            sims = (sel_embs @ q_emb.reshape(-1, 1)).ravel()
            reranked = sorted(zip(sel_texts, sel_metas, sims.tolist()), key=lambda x: x[2], reverse=True)

        final = reranked[:FINAL_K]
        final_chunks = [r[0] for r in final]
        final_metas = [r[1] for r in final]
        raw_scores = [r[2] for r in final]

        # --- Adaptive confidence gate (scores normalized to a common [0,1]) ---
        confident = False
        if raw_scores:
            norm = normalize_rerank_scores(raw_scores, used_cross_encoder)
            s_sorted = sorted(norm, reverse=True)
            top = s_sorted[0]
            cond1 = top >= MIN_TOP_SCORE
            cond2 = (top - s_sorted[1]) >= DELTA_TOP2 if len(s_sorted) >= 2 else True
            mu = float(np.mean(norm))
            sd = float(np.std(norm)) or 1.0
            cond3 = (top - mu) >= MEAN_GAP_FACTOR * sd
            confident = cond1 and cond2 and cond3

            if not confident and required_aliases_present(query, final_chunks):
                logging.info("Keyword-preserve: required alias found -> accept.")
                confident = True
            if not confident:
                q_kws = extract_keywords(query)
                if any(any(kw in (txt or "").lower() for txt in final_chunks) for kw in q_kws):
                    logging.info("Exact keyword match in retrieved chunks -> accept.")
                    confident = True

        # --- Answer ---
        if intent == "AI" and confident and final_chunks:
            context = "\n\n---\n\n".join(final_chunks)
            sys_instr = (
                "You are a precise research assistant. Use ONLY the provided CONTEXT "
                "to answer. If the context lacks the answer, say \"Not found in documents\" "
                "and then give a concise general summary."
            )
            q_low = query.lower()
            if any(tok in q_low for tok in (" vs ", " difference", "compare", "vs.")):
                format_hint = "Format the main answer as a concise Markdown table, then a 1-2 sentence summary."
            elif any(tok in q_low for tok in ("advantages", "disadvantages", "pros", "cons")):
                format_hint = "Give pros (bullets), then cons (bullets)."
            elif any(tok in q_low for tok in ("how to", "steps", "process")):
                format_hint = "Provide a numbered step-by-step procedure."
            else:
                format_hint = ""

            prompt = f"{sys_instr}\n{format_hint}\n\nContext:\n{context}\n\nQuestion: {query}\nAnswer:"
            answer = call_local_llm(prompt)
            source_str = ", ".join(sorted({
                m.get("source", "unknown") + (f":p{m.get('page')}" if m.get("page") else "")
                for m in final_metas
            }))
            print("\nAnswer (from docs):\n", answer.strip())
            print("\nSource:", source_str or "unknown")
        else:
            logging.info("Fallback: answering with general LLM (not grounded in docs).")
            if intent == "CODING":
                prompt = f"You are a coding assistant. Provide a clean code example and brief explanation. Question: {query}"
            else:
                prompt = f"Answer concisely and helpfully: {query}"
            answer = call_local_llm(prompt)
            print("\nAnswer:\n", answer.strip())
            print("\nSource: none (general)")

        print(f"\nTook {now_s() - t0:.2f}s\n")


if __name__ == "__main__":
    main()
