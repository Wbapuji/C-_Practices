# utils.py
# Single source of truth for text cleaning and chunking.
# Both ingest.py and query.py import from here (no duplicated logic).

import re
from typing import List


def clean_text(text: str) -> str:
    """
    Normalize whitespace (including newlines from PDF extraction) into single
    spaces and strip non-printable control characters. Safe on None/empty input.
    """
    if not text:
        return ""
    # Collapse all runs of whitespace (spaces, tabs, newlines) into a single space
    text = re.sub(r"\s+", " ", text).strip()
    # Drop non-printable control characters that PDFs sometimes embed
    text = "".join(ch for ch in text if ch.isprintable())
    return text


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    """
    Word-based sliding-window chunking with overlap.
    Good default for MPNet-style bi-encoders.

    chunk_size: max words per chunk
    overlap:    words shared between consecutive chunks (preserves context
                across boundaries so an answer split across two chunks is
                still retrievable)
    """
    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    words = text.split()
    if not words:
        return []

    chunks: List[str] = []
    start = 0
    step = max(1, chunk_size - overlap)
    while start < len(words):
        end = min(len(words), start + chunk_size)
        chunk = " ".join(words[start:end]).strip()
        if chunk:
            chunks.append(chunk)
        if end == len(words):
            break
        start += step
    return chunks


def tokenize_for_bm25(text: str) -> List[str]:
    """
    Lightweight, case-insensitive tokenizer for BM25.
    Lowercasing here (and at query time) fixes BM25's case-sensitivity so
    'RAG' and 'rag' match. Keeps alphanumerics and hyphens (e.g. 'low-rank').
    """
    return re.findall(r"[a-z0-9\-]+", text.lower())
